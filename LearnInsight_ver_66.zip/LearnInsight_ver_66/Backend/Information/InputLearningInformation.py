
from LearnInsight_ver_66.Backend.Database.ConnectDatabase import ConnectDatabase


class InputLearningInformation:
    def __init__(self):
        self.db = ConnectDatabase()
        self.connection = self.db.connect()
        self.cursor = self.connection.cursor()

    def input_learning_data(self, user_id, subject, study_time, score, learning_date, class_name=None):
        query = """
        INSERT INTO learning_information (user_id, subject, study_time, score, learning_date, class_name)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.cursor.execute(query, (user_id, subject, study_time, score, learning_date, class_name))
        self.connection.commit()
        return self.cursor.lastrowid

    def get_learning_data_by_user(self, user_id):
        query = """
        SELECT id, user_id, subject, study_time, score, learning_date, created_at, updated_at, class_name
        FROM learning_information
        WHERE user_id = %s
        ORDER BY learning_date ASC, id ASC
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query, (user_id,))
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def add_learning_record(self, user_id, subject, study_time, score, class_name):
        db = ConnectDatabase()
        conn = db.connect()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO learning_information (user_id, subject, study_time, score, class_name, learning_date)
            VALUES (%s, %s, %s, %s, %s, CURRENT_DATE())
            """,
            (user_id, subject, study_time, score, class_name),
        )
        conn.commit()
        cursor.close()
        conn.close()

    def close(self):
        try:
            self.cursor.close()
        except Exception:
            pass
        self.db.close()
