
import os

class AppConfig:
    DB_HOST = os.getenv("LEARNINSIGHT_DB_HOST", "localhost")
    DB_PORT = int(os.getenv("LEARNINSIGHT_DB_PORT", "3306"))
    DB_USER = os.getenv("LEARNINSIGHT_DB_USER", "root")
    DB_PASSWORD = os.getenv("LEARNINSIGHT_DB_PASSWORD", "root1234")
    DB_NAME = os.getenv("LEARNINSIGHT_DB_NAME", "learninsight")
    SECRET_KEY = os.getenv("LEARNINSIGHT_SECRET_KEY", "learninsight_secret_key")
    UPLOAD_FOLDER_NAME = os.getenv("LEARNINSIGHT_UPLOAD_FOLDER", "uploads")
    LOCAL_MODEL = os.getenv("LEARNINSIGHT_LOCAL_MODEL", "llama3.2:3b")
    OLLAMA_URL = os.getenv("LEARNINSIGHT_OLLAMA_URL", "http://127.0.0.1:11434/api/generate")
