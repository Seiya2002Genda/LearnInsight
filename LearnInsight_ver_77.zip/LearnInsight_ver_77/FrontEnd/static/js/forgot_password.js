document.addEventListener("DOMContentLoaded",function(){

    const form=document.querySelector("form")
    const passwordInput=document.querySelector("input[name='password']")

    form.addEventListener("submit",function(e){

        const password=passwordInput.value

        if(password.length<6){
            e.preventDefault()
            alert("Password must be at least 6 characters.")
            return
        }

    })

})