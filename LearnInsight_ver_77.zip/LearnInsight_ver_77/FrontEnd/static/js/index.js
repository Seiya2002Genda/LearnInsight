document.addEventListener("DOMContentLoaded", async () => {
  const statusEl = document.getElementById("landing-ai-status");
  if (!statusEl) return;
  try {
    const res = await fetch("/api/ai/status");
    const data = await res.json();
    if (data && data.mode) {
      statusEl.textContent = data.connected
        ? `Local model online: ${data.model}`
        : `Fallback assistant active: ${data.model}`;
    }
  } catch {
    statusEl.textContent = "Sign in to see live AI status.";
  }
});
