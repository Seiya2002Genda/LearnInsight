document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("llm-form");
  const input = document.getElementById("llm-input");
  const chatBox = document.getElementById("llm-chat-box");
  const prompts = document.querySelectorAll(".ai-prompt");

  const addMessage = (role, text) => {
    if (!chatBox) return;
    const row = document.createElement("div");
    row.className = `llm-message ${role}`;
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;
    row.appendChild(bubble);
    chatBox.appendChild(row);
    chatBox.scrollTop = chatBox.scrollHeight;
  };

  if (chatBox) {
    addMessage("assistant", "Hello. I am your LearnInsight local study assistant. Ask me to prioritize work, explain a concept, or build a plan.");
  }

  prompts.forEach((btn) => {
    btn.addEventListener("click", () => {
      if (input) {
        input.value = btn.textContent.trim();
        input.focus();
      }
    });
  });

  if (form && input && chatBox) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const message = input.value.trim();
      if (!message) return;
      addMessage("user", message);
      input.value = "";
      addMessage("assistant", "Thinking...");
      const loadingMessage = chatBox.lastElementChild;
      try {
        const response = await fetch("/ai/chat", {
          method: "POST",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({message})
        });
        const data = await response.json();
        if (loadingMessage) loadingMessage.remove();
        addMessage("assistant", data.reply || "No response received.");
      } catch (err) {
        if (loadingMessage) loadingMessage.remove();
        addMessage("assistant", "The AI assistant is temporarily unavailable.");
      }
    });
  }
});