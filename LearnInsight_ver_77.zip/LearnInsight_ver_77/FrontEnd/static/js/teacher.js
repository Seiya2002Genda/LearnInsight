document.addEventListener("DOMContentLoaded", function(){
  const scoreRows=document.querySelectorAll(".student-table tbody tr");
  let labels=[],scores=[],times=[];
  scoreRows.forEach(row=>{
    const name=row.querySelector(".student-name")?.innerText?.trim();
    const score=parseFloat(row.querySelector(".score")?.innerText)||0;
    const time=parseFloat(row.querySelector(".study-time")?.innerText)||0;
    if(name){labels.push(name);scores.push(score);times.push(time);}
  });
  if(typeof Chart!=="undefined"){
    const scoreCanvas=document.getElementById("scoreChart");
    if(scoreCanvas) new Chart(scoreCanvas.getContext("2d"),{type:"bar",data:{labels,datasets:[{label:"Score",data:scores}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,max:100}}}});
    const studyCanvas=document.getElementById("studyTimeChart");
    if(studyCanvas) new Chart(studyCanvas.getContext("2d"),{type:"bar",data:{labels,datasets:[{label:"Study Time",data:times}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
  }

  const form = document.getElementById("teacher-ai-form");
  const input = document.getElementById("teacher-ai-input");
  const chatBox = document.getElementById("teacher-ai-chat-box");
  const prompts = document.querySelectorAll(".teacher-ai-panel .ai-prompt");

  const addMessage = (role, text) => {
    if (!chatBox) return;
    const row = document.createElement("div");
    row.className = `llm-message ${role}`;
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;
    row.appendChild(bubble);
    chatBox.appendChild(row);
    chatBox.scrollTop = chatBox.scrollHeight;
  };

  if (chatBox) {
    addMessage("assistant", "Hello. I am your LearnInsight teaching assistant. Ask for interventions, lesson ideas, and feedback wording.");
  }

  prompts.forEach((btn) => {
    btn.addEventListener("click", () => {
      if (input) {
        input.value = btn.textContent.trim();
        input.focus();
      }
    });
  });

  if (form && input) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const message = input.value.trim();
      if (!message) return;
      addMessage("user", message);
      input.value = "";
      addMessage("assistant", "Thinking...");
      const loadingMessage = chatBox.lastElementChild;
      try {
        const response = await fetch("/ai/chat", {
          method: "POST",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({message})
        });
        const data = await response.json();
        if (loadingMessage) loadingMessage.remove();
        addMessage("assistant", data.reply || "No response received.");
      } catch (err) {
        if (loadingMessage) loadingMessage.remove();
        addMessage("assistant", "The AI assistant is temporarily unavailable.");
      }
    });
  }
});