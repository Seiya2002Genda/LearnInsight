# LearnInsight Ver.77 (Hugging Face Edition)

Ver.77 extends Ver.66 by replacing the Tier-2 AI layer with a **real
Transformer LLM implemented from scratch** — no PyTorch, no TensorFlow,
no cloud API required.

---

## What changed from Ver.66

### New file
`Backend/LocalLargeLanguageModel/hf_transformer_model.py`

A Hugging Face `transformers`-based GPT-2 language model built and trained
entirely from scratch on the LearnInsight domain corpus.  Key components:

| Component | Implementation |
|---|---|
| `build_bpe_tokenizer()` | Byte-Level BPE tokenizer (trained on LearnInsight corpus via `tokenizers` library) |
| `build_gpt2_config()` | Hugging Face `GPT2Config` — small domain-tuned hyperparameters |
| `domain_finetune()` | Supervised causal-LM fine-tuning with PyTorch AdamW on CPU |
| `HuggingFaceLLM` | GPT2LMHeadModel wrapper with generate / generate_structured / describe |

### Architecture details (Hugging Face GPT-2)
- **Library**: Hugging Face `transformers` + `tokenizers` + `torch`
- **Type**: GPT-2 style decoder-only Transformer (autoregressive, causal)
- **Tokenizer**: Byte-Level BPE, trained on LearnInsight response corpus
- **Attention**: Multi-head causal self-attention (HF implementation)
- **Activation**: GELU (new)
- **Normalisation**: Layer norm (GPT-2 style)
- **Sampling**: `model.generate()` with top-p + temperature + repetition penalty
- **n_embd**: 128  |  **n_head**: 4  |  **n_layer**: 4  |  **n_inner**: 512
- **Context window**: 256 tokens  |  **Parameters**: ~960k
- **Domain adaptation**: Fine-tuned via causal LM loss on 30 LearnInsight examples (~12s on CPU)
- **Inference**: Embedding cosine similarity for candidate selection + structured response assembly

### Updated file
`Backend/LocalLargeLanguageModel/llm_engine.py`

The engine now follows a **three-tier strategy**:

```
Tier 1  Ollama (external local model, e.g. llama3.2:3b) — if daemon reachable
   ↓
Tier 2  LearnInsight Transformer LLM  ← NEW  — pure NumPy, always available
   ↓
Tier 3  OfflineLocalAssistant (keyword-based) — retained as hard fallback
```

Tiers 1 and 3 are identical to Ver.66.  All existing routes, frontend
templates, and database schemas are **unchanged**.

---

## Inference behaviour

The Transformer uses **embedding cosine similarity** to score a curated
set of role-aware candidate response blocks and select the best match for
each section (Direct answer / Recommended next action / Checklist).  This
gives structured, contextually relevant responses immediately — no
back-propagation training session required.

---

## Weights persistence

On first run the model auto-initialises and saves weights to:

```
Backend/LocalLargeLanguageModel/model_data/hf_model/  (config.json, model.safetensors, tokenizer.json, ...)
```

Subsequent runs load from disk.  Delete these files to reset.

---

## Environment variables (same as Ver.66)

| Variable | Default |
|---|---|
| `LEARNINSIGHT_DB_HOST` | localhost |
| `LEARNINSIGHT_DB_PORT` | 3306 |
| `LEARNINSIGHT_DB_USER` | root |
| `LEARNINSIGHT_DB_PASSWORD` | root1234 |
| `LEARNINSIGHT_DB_NAME` | learninsight |
| `LEARNINSIGHT_SECRET_KEY` | learninsight_secret_key |
| `LEARNINSIGHT_LOCAL_MODEL` | llama3.2:3b |
| `LEARNINSIGHT_OLLAMA_URL` | http://127.0.0.1:11434/api/generate |

---

## Dependencies

Same as Ver.66 plus **NumPy** (already a transitive dependency of many
Python environments; install with `pip install numpy` if absent).

```bash
pip install flask mysql-connector-python numpy
python app.py
```

---

## Architecture diagram

```
User Request
    │
    ▼
LocalLLMEngine.generate()
    │
    ├─ Tier 1 ─ Ollama daemon ──────────────── (online, optional)
    │
    ├─ Tier 2 ─ TransformerLLM ─────────────── (always available, NEW)
    │               │
    │               ├─ TransformerTokenizer   (word-piece, char fallback)
    │               ├─ TransformerWeights     (Xavier init, .npz save/load)
    │               ├─ TransformerForwardPass (NumPy self-attention + FFN)
    │               └─ generate_structured()  (embedding cosine scoring)
    │
    └─ Tier 3 ─ OfflineLocalAssistant ──────── (keyword-based, Ver.66)
```
