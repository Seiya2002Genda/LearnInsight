
import mysql.connector
from mysql.connector import Error
from LearnInsight_ver_77.Backend.config import AppConfig


class ConnectDatabase:
    def __init__(self, database=None):
        self.database = database or AppConfig.DB_NAME
        self.connection = None

    def connect(self):
        if self.connection is not None and self.connection.is_connected():
            return self.connection
        self.connection = mysql.connector.connect(
            host=AppConfig.DB_HOST,
            port=AppConfig.DB_PORT,
            user=AppConfig.DB_USER,
            password=AppConfig.DB_PASSWORD,
            database=self.database,
            autocommit=False,
        )
        return self.connection

    def cursor(self, dictionary=True, buffered=False):
        if self.connection is None or not self.connection.is_connected():
            self.connect()
        return self.connection.cursor(dictionary=dictionary, buffered=buffered)

    def test_connection(self):
        try:
            conn = self.connect()
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            return True
        except Error:
            return False

    def close(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()
            self.connection = None
