
import hashlib
from LearnInsight_ver_77.Backend.Database.ConnectDatabase import ConnectDatabase


class MakeAccount:
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def username_exists(self, username):
        db = ConnectDatabase()
        conn = db.connect()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
        result = cursor.fetchone() is not None
        cursor.close()
        conn.close()
        return result

    def email_exists(self, email):
        db = ConnectDatabase()
        conn = db.connect()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        result = cursor.fetchone() is not None
        cursor.close()
        conn.close()
        return result

    def create_account(self, username, password, email, role):
        if self.username_exists(username):
            return {"success": False, "message": "Username already exists"}
        if self.email_exists(email):
            return {"success": False, "message": "Email already exists"}

        db = ConnectDatabase()
        conn = db.connect()
        cursor = conn.cursor(dictionary=True)
        hashed_password = self.hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password, email, role) VALUES (%s, %s, %s, %s)",
            (username, hashed_password, email, role),
        )
        conn.commit()
        user_id = cursor.lastrowid
        cursor.close()
        conn.close()
        return {"success": True, "message": "Account Created", "user_id": user_id}
