
from .tokenizer import Tokenizer
from .knowledge_base import KnowledgeBase


class StudentAI:
    def __init__(self):
        self.tokenizer = Tokenizer()
        self.kb = KnowledgeBase()

    def _format_plan(self, topic, knowledge, username):
        return f"""Study Coach for {username}

Topic detected: {topic}

What to focus on
{knowledge}

3-step action plan
1. Spend 25 minutes reviewing the core idea and write 3 key points in your own words.
2. Solve 2-3 examples without looking at notes, then check mistakes.
3. End with a 5-minute recap: define the concept, explain it, and list one weak area to revisit.

Quick check
- Can you explain the idea in plain language?
- Can you solve one example alone?
- Do you know what to review next?"""

    def answer(self, message, context):
        username = context.get("username", "Learner")
        tokens = self.tokenizer.tokenize(message)
        knowledge = self.kb.search(tokens)
        topic = " ".join(tokens[:6]) if tokens else "general study"
        if knowledge:
            return self._format_plan(topic, knowledge, username)
        return f"""Study Coach for {username}

I could not match that to a specific stored topic, so here is a strong general study workflow:

1. Clarify the goal in one sentence.
2. Break the topic into small chunks.
3. Learn one chunk, then immediately test yourself.
4. Review errors before moving on.
5. Finish with spaced repetition later today.

Send me the course name, topic, or homework question for a more targeted answer."""
