
from .tokenizer import Tokenizer


class IntentClassifier:
    def __init__(self):
        self.tokenizer = Tokenizer()

    def classify(self, text):
        tokens = set(self.tokenizer.tokenize(text))

        teacher_keywords = {"assignment", "rubric", "quiz", "lesson", "worksheet", "grade", "classroom"}
        admin_keywords = {"school", "admin", "performance", "attendance", "dashboard", "analytics"}
        recommendation_keywords = {"recommend", "plan", "schedule", "improve", "strategy", "roadmap"}

        if tokens & teacher_keywords:
            return "teacher"
        if tokens & admin_keywords:
            return "admin"
        if tokens & recommendation_keywords:
            return "recommendation"
        return "student"
