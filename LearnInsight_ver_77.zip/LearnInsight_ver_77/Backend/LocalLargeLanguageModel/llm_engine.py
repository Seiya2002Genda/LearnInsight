import json
import os
from urllib import request

from .intent_classifier import IntentClassifier
from .student_ai import StudentAI
from .teacher_ai import TeacherAI
from .admin_ai import AdminAI
from .recommendation_ai import RecommendationAI
from .offline_local_assistant import OfflineLocalAssistant
from .hf_transformer_model import HuggingFaceLLM
from LearnInsight_ver_77.Backend.config import AppConfig


class LocalLLMEngine:
    """
    LearnInsight Ver.77 LLM Engine — three-tier inference strategy:

    Tier 1 — Ollama (external local model, e.g. llama3.2:3b)
             Used when the Ollama daemon is reachable.
    Tier 2 — HuggingFaceLLM  (NEW in Ver.77)
             GPT-2 style model built with Hugging Face `transformers`.
             BPE tokenizer + GPT2LMHeadModel trained on LearnInsight corpus.
             Runs fully offline on CPU — no download, no cloud API needed.
             Model is saved to model_data/hf_model/ on first run.
    Tier 3 — OfflineLocalAssistant (keyword-based fallback)
             Retained for zero-dependency environments.
    """

    # Path for the Hugging Face model artefacts
    _MODULE_DIR  = os.path.dirname(os.path.abspath(__file__))
    _HF_MODEL_DIR = os.path.join(_MODULE_DIR, "model_data", "hf_model")

    def __init__(self, model_name=None, ollama_url=None):
        self.classifier = IntentClassifier()
        self.student_ai = StudentAI()
        self.teacher_ai = TeacherAI()
        self.admin_ai = AdminAI()
        self.recommend_ai = RecommendationAI()
        self.offline_assistant = OfflineLocalAssistant()
        self.model_name = model_name or AppConfig.LOCAL_MODEL
        self.ollama_url = ollama_url or AppConfig.OLLAMA_URL

        # ── Tier 2: Hugging Face LLM (GPT-2 + BPE, trained on domain corpus) ─
        os.makedirs(self._HF_MODEL_DIR, exist_ok=True)
        self._hf_llm = HuggingFaceLLM(model_dir=self._HF_MODEL_DIR)

    def _build_prompt(self, message, context):
        username = context.get("username", "Learner")
        role = context.get("role", "student")
        metrics = []
        for key in [
            "average_score", "assignment_count", "task_count", "student_count", "completion_rate", "pending_tasks", "risk_level"
        ]:
            if key in context:
                metrics.append(f"{key}: {context[key]}")
        metrics_text = "\n".join(metrics) if metrics else "No platform metrics supplied."
        return (
            "You are LearnInsight AI, a local-first education copilot. "
            "Give concise, structured answers linked to platform actions.\n\n"
            f"User role: {role}\n"
            f"User name: {username}\n"
            f"Platform metrics:\n{metrics_text}\n\n"
            f"User message: {message}\n\n"
            "Output format:\n1) Direct answer\n2) Recommended next action\n3) Optional short checklist if useful\n"
        )

    def _generate_with_ollama(self, prompt):
        payload = json.dumps({
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.35}
        }).encode("utf-8")
        req = request.Request(
            self.ollama_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return (data.get("response") or "").strip()

    def ollama_available(self):
        try:
            sample = self._generate_with_ollama("Reply with the single word: ready")
            return bool(sample)
        except Exception:
            return False

    def status(self):
        connected = self.ollama_available()
        hf_info = self._hf_llm.describe()
        return {
            "connected": connected,
            "mode":  "ollama" if connected else "huggingface-local",
            "model": self.model_name if connected else "HuggingFace GPT-2 (Ver.77)",
            "hf_model": hf_info,
        }

    def describe_mode(self):
        state = self.status()
        if state["connected"]:
            return f"Connected to local Ollama model ({state['model']})."
        info = state["hf_model"]
        return (
            f"Using {info['architecture']} via {info['library']} — "
            f"{info['parameters']:,} parameters, "
            f"vocab {info['vocab_size']}, "
            f"{info['n_layer']} layers × {info['n_head']} heads. "
            "No cloud API or Ollama required."
        )

    def quick_suggestions(self, role="student"):
        if role == "teacher":
            return [
                "Create a 1-week intervention plan for low-performing students",
                "Draft feedback comments for missing assignments",
                "Suggest a lesson warm-up for tomorrow's class"
            ]
        if role in {"schooladministrator", "systemadministrator"}:
            return [
                "Summarize platform performance risks",
                "Suggest admin KPI dashboard metrics",
                "Recommend actions to improve usage"
            ]
        return [
            "Build a 3-day study plan for my next assignment",
            "Explain this concept step by step",
            "Help me prioritize my current tasks"
        ]

    def _generate_with_hf(self, message, context):
        """
        Tier 2 — Hugging Face LLM (GPT-2 + BPE, trained on LearnInsight corpus).
        Uses the HF model's token embeddings for cosine-similarity candidate
        selection, then returns a structured LearnInsight response.
        """
        return self._hf_llm.generate_structured(message, context)

    def _fallback(self, message, context):
        """Tier 3 — keyword-based offline assistant (unchanged from Ver.66)."""
        intent = self.classifier.classify(message)
        role = context.get("role", "student")

        if role == "teacher" or intent == "teacher":
            return self.offline_assistant.generate(message, {**context, "role": "teacher"})
        if role in {"schooladministrator", "systemadministrator"} or intent == "admin":
            return self.offline_assistant.generate(message, {**context, "role": role})
        if intent == "recommendation":
            rec = self.recommend_ai.recommend(context)
            return (
                "Direct answer\n"
                f"{rec}\n\n"
                "Recommended next action\n"
                "Follow the highest-impact study action today before adding new work."
            )
        return self.offline_assistant.generate(message, context)

    def generate(self, message, context=None):
        """
        Three-tier generate:
          1. Ollama (if reachable)
          2. LearnInsight Transformer LLM  <- NEW in Ver.77
          3. OfflineLocalAssistant (keyword fallback)
        """
        context = context or {}
        message = (message or "").strip()
        if not message:
            return "Please enter a question for the AI assistant."

        # Tier 1: Ollama
        prompt = self._build_prompt(message, context)
        try:
            response = self._generate_with_ollama(prompt)
            if response:
                return response
        except Exception:
            pass

        # Tier 2: Hugging Face LLM
        try:
            response = self._generate_with_hf(message, context)
            if response:
                return response
        except Exception:
            pass

        # Tier 3: keyword fallback
        return self._fallback(message, context)
