"""
LearnInsight Ver.77 — Hugging Face Transformer LLM
===================================================
Uses the Hugging Face `transformers` library to build a GPT-2 style
decoder-only language model entirely from scratch — no internet download,
no pretrained weights file needed.

Architecture (Hugging Face GPT2LMHeadModel)
  - Byte-Pair Encoding tokenizer (trained on the LearnInsight domain corpus)
  - GPT-2 style decoder-only Transformer
  - Causal (masked) multi-head self-attention
  - Learned positional embeddings
  - LayerNorm + GELU + tied input/output embeddings

Design goals
  - Replace the NumPy transformer with a proper HuggingFace model object
  - All weights are initialised locally (Xavier / HF default init)
  - Domain adaptation via short supervised fine-tuning on LearnInsight corpus
  - Model + tokenizer saved to disk in standard HuggingFace format
    (model_data/hf_model/)  and reloaded on subsequent runs
  - Public interface matches the NumPy version:
      hf_llm.generate_structured(message, context) → str
      hf_llm.generate(prompt)                      → str
      hf_llm.describe()                            → dict
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path
from typing import Optional

# ── Hugging Face imports ──────────────────────────────────────────────────────
import torch
from transformers import (
    GPT2Config,
    GPT2LMHeadModel,
    PreTrainedTokenizerFast,
)
from tokenizers import Tokenizer as HFTokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import ByteLevel
from tokenizers.decoders import ByteLevel as ByteLevelDecoder


# ─────────────────────────────────────────────────────────────────────────────
# 1. Domain corpus — LearnInsight structured response examples
#    Used both to train the BPE tokenizer and to fine-tune the model.
# ─────────────────────────────────────────────────────────────────────────────

DOMAIN_CORPUS: list[str] = [
    # ── Student responses ──────────────────────────────────────────────────
    "Direct answer\nFocus on your current assignment. Break the topic into three small steps and complete one now.\n\nRecommended next action\nStart with the highest-deadline item and work for 25 minutes, then check what improved.\n\nChecklist\n- Pick one target\n- Study or submit now\n- Review mistakes after",

    "Direct answer\nYour score suggests reviewing fundamentals first. Identify the core concept and write it in your own words.\n\nRecommended next action\nSolve two practice problems without notes, then compare with the answer key.\n\nChecklist\n- Read the chapter summary\n- Solve one example problem\n- Note what was unclear",

    "Direct answer\nStrong performance. Push to advanced topics and challenge yourself with harder exercises.\n\nRecommended next action\nAttempt an exam-level question today and time yourself.\n\nChecklist\n- Pick an advanced problem\n- Work without hints\n- Review your approach",

    "Direct answer\nBuild a study plan by listing all topics, estimating time per topic, and scheduling blocks.\n\nRecommended next action\nCreate a three-day plan: day one review, day two practice, day three mock test.\n\nChecklist\n- List all topics\n- Estimate time per topic\n- Schedule in your calendar",

    "Direct answer\nTo improve your grade, focus on the areas where you lost the most points in past assignments.\n\nRecommended next action\nReview your last three graded assignments and list repeated mistakes.\n\nChecklist\n- Review graded work\n- List error patterns\n- Redo similar problems",

    "Direct answer\nFor math study, practice is more important than reading. Solve problems daily.\n\nRecommended next action\nComplete five problems from the current chapter before the next class.\n\nChecklist\n- Read worked example\n- Solve without looking\n- Check and correct",

    "Direct answer\nAlgorithm study requires understanding time complexity and practising on real problems.\n\nRecommended next action\nSolve one easy problem on arrays or strings today and analyse its complexity.\n\nChecklist\n- Understand the problem\n- Write a solution\n- Check complexity",

    "Direct answer\nDatabase study involves SQL queries and understanding normalisation rules.\n\nRecommended next action\nPractise writing SELECT, JOIN, and GROUP BY queries on a sample schema.\n\nChecklist\n- Write a basic SELECT\n- Try a JOIN query\n- Understand GROUP BY",

    # ── Teacher responses ──────────────────────────────────────────────────
    "Direct answer\nTo create an assignment, define a clear objective, provide instructions, and attach a rubric.\n\nRecommended next action\nIdentify the lowest-performing student group and design one targeted task for them.\n\nChecklist\n- Set objective\n- Write instructions\n- Create rubric",

    "Direct answer\nFor student intervention, first identify who needs support using score and submission data.\n\nRecommended next action\nSend personalised feedback to the three students with the lowest recent scores.\n\nChecklist\n- Identify at-risk students\n- Draft feedback message\n- Schedule a check-in",

    "Direct answer\nA one-week lesson plan should include learning goals, daily activities, and assessments.\n\nRecommended next action\nWrite Monday and Tuesday plans first, then adapt based on student engagement.\n\nChecklist\n- Define weekly goal\n- Plan daily activity\n- Plan assessment",

    "Direct answer\nTo grade fairly, use a rubric with clear criteria for accuracy, clarity, and application.\n\nRecommended next action\nGrade one batch today and note common errors to address in the next class.\n\nChecklist\n- Use rubric consistently\n- Note common mistakes\n- Give written feedback",

    # ── Admin responses ─────────────────────────────────────────────────────
    "Direct answer\nPlatform performance should be reviewed using completion rate, login frequency, and assignment submission trends.\n\nRecommended next action\nCompare engagement by role and fix the largest workflow bottleneck first.\n\nChecklist\n- Pull adoption metrics\n- Check risk signals\n- Prioritise one fix",

    "Direct answer\nTo improve platform usage, identify the features least used and investigate barriers to adoption.\n\nRecommended next action\nExport a completion-rate report and share findings with department heads.\n\nChecklist\n- Export usage report\n- Find low-use features\n- Share with stakeholders",

    "Direct answer\nSystem configuration changes should be preceded by an audit of current login and submission data.\n\nRecommended next action\nAudit the last 30 days of activity logs before making system changes.\n\nChecklist\n- Export activity log\n- Check anomalies\n- Document changes",

    # ── Generic Q&A pairs ───────────────────────────────────────────────────
    "How can I improve my study habits? Focus on active recall and spaced repetition. Test yourself regularly instead of re-reading notes.",
    "What is the best way to prepare for an exam? Create a schedule, review past mistakes, and simulate exam conditions.",
    "How do I write better assignments? Understand the rubric, plan before writing, and proofread for clarity.",
    "How can a teacher support struggling students? Use data to identify them early, give specific feedback, and follow up.",
    "What metrics matter for school performance? Completion rate, average score, submission rate, and login frequency.",
    "How do I use LearnInsight effectively? Log in daily, check your tasks, review feedback, and track your progress.",
    "How do I create a quiz? Define learning objectives first, then write questions at multiple difficulty levels.",
    "What is a good rubric? A rubric should have clear criteria, defined performance levels, and point allocation.",
    "How do I analyse student performance? Sort by score, identify patterns in errors, and group students by need.",
    "What does a risk level mean? Risk level indicates the likelihood a student will underperform based on recent activity.",
]


# ─────────────────────────────────────────────────────────────────────────────
# 2. BPE Tokenizer — trained on domain corpus
# ─────────────────────────────────────────────────────────────────────────────

SPECIAL_TOKENS = ["<|pad|>", "<|unk|>", "<|bos|>", "<|eos|>"]
VOCAB_SIZE = 2048  # small enough for a domain-specific model


def build_bpe_tokenizer(corpus: list[str]) -> PreTrainedTokenizerFast:
    """
    Train a Byte-Level BPE tokenizer on the LearnInsight corpus.
    Returns a HuggingFace PreTrainedTokenizerFast.
    """
    hf_tok = HFTokenizer(BPE(unk_token="<|unk|>"))
    hf_tok.pre_tokenizer = ByteLevel(add_prefix_space=False)
    hf_tok.decoder = ByteLevelDecoder()

    trainer = BpeTrainer(
        vocab_size=VOCAB_SIZE,
        special_tokens=SPECIAL_TOKENS,
        min_frequency=1,
        show_progress=False,
    )

    # Write corpus to a temp file for the trainer
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                     delete=False, encoding="utf-8") as f:
        f.write("\n".join(corpus))
        tmp_path = f.name

    try:
        hf_tok.train([tmp_path], trainer=trainer)
    finally:
        os.unlink(tmp_path)

    tokenizer = PreTrainedTokenizerFast(
        tokenizer_object=hf_tok,
        bos_token="<|bos|>",
        eos_token="<|eos|>",
        unk_token="<|unk|>",
        pad_token="<|pad|>",
    )
    return tokenizer


# ─────────────────────────────────────────────────────────────────────────────
# 3. GPT-2 model configuration — small domain model
# ─────────────────────────────────────────────────────────────────────────────

def build_gpt2_config(vocab_size: int) -> GPT2Config:
    """
    Build a small GPT-2 config suitable for CPU inference.

    Hyperparameters:
      n_layer  = 4   transformer blocks
      n_head   = 4   attention heads
      n_embd   = 128 embedding dimension
      n_inner  = 512 FFN hidden size  (4 × n_embd)
      n_positions = 256  context window
      ~3.4 M parameters — fast on CPU, meaningful structure
    """
    return GPT2Config(
        vocab_size=vocab_size,
        n_positions=256,
        n_ctx=256,
        n_embd=128,
        n_layer=4,
        n_head=4,
        n_inner=512,
        activation_function="gelu_new",
        resid_pdrop=0.0,
        embd_pdrop=0.0,
        attn_pdrop=0.0,
        layer_norm_epsilon=1e-5,
        initializer_range=0.02,
        bos_token_id=None,   # set after tokenizer is built
        eos_token_id=None,
    )


# ─────────────────────────────────────────────────────────────────────────────
# 4. Domain fine-tuning  (gradient-based, pure PyTorch, CPU)
# ─────────────────────────────────────────────────────────────────────────────

def domain_finetune(
    model: GPT2LMHeadModel,
    tokenizer: PreTrainedTokenizerFast,
    corpus: list[str],
    epochs: int = 8,
    lr: float = 5e-3,
    max_len: int = 200,
) -> None:
    """
    Fine-tune the model on the LearnInsight corpus using causal language
    modelling loss.  Runs entirely on CPU — takes ~5-15 seconds for the
    small model size used here.
    """
    model.train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)

    # Tokenise all examples
    all_input_ids: list[torch.Tensor] = []
    for text in corpus:
        enc = tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=max_len,
            padding=False,
        )
        ids = enc["input_ids"].squeeze(0)   # (T,)
        if ids.shape[0] >= 4:               # skip tiny sequences
            all_input_ids.append(ids)

    if not all_input_ids:
        return

    for epoch in range(epochs):
        total_loss = 0.0
        for ids in all_input_ids:
            ids = ids.unsqueeze(0)          # (1, T)
            # Causal LM: labels = input shifted left (HF does this internally)
            outputs = model(input_ids=ids, labels=ids)
            loss = outputs.loss
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total_loss += loss.item()

    model.eval()


# ─────────────────────────────────────────────────────────────────────────────
# 5. HuggingFaceLLM — public interface
# ─────────────────────────────────────────────────────────────────────────────

class HuggingFaceLLM:
    """
    LearnInsight Hugging Face LLM.

    Uses GPT2LMHeadModel from the `transformers` library with a custom
    BPE tokenizer, trained from scratch on the LearnInsight domain corpus.
    No pretrained weights download required.

    Public interface (mirrors NumPy TransformerLLM):
      generate_structured(message, context) → structured str
      generate(prompt, max_new_tokens, temperature, top_p) → str
      describe() → dict
    """

    MODEL_DIR_NAME = "hf_model"

    def __init__(self, model_dir: Optional[str] = None):
        self.model_dir = model_dir
        self.device = torch.device("cpu")

        if model_dir and (Path(model_dir) / "config.json").exists():
            self._load(model_dir)
        else:
            self._build_and_train()
            if model_dir:
                self._save(model_dir)

    # ── Build, train, save, load ─────────────────────────────────────────────

    def _build_and_train(self) -> None:
        """Build tokenizer + model from scratch and fine-tune on corpus."""
        # 1. Tokenizer
        self.tokenizer = build_bpe_tokenizer(DOMAIN_CORPUS)

        # 2. Model config
        config = build_gpt2_config(vocab_size=len(self.tokenizer))
        config.bos_token_id = self.tokenizer.bos_token_id
        config.eos_token_id = self.tokenizer.eos_token_id
        config.pad_token_id = self.tokenizer.pad_token_id

        # 3. Model (random init, then fine-tune)
        self.model = GPT2LMHeadModel(config)
        self.model.to(self.device)

        # 4. Domain fine-tuning
        domain_finetune(self.model, self.tokenizer, DOMAIN_CORPUS)

    def _save(self, model_dir: str) -> None:
        os.makedirs(model_dir, exist_ok=True)
        self.model.save_pretrained(model_dir)
        self.tokenizer.save_pretrained(model_dir)

    def _load(self, model_dir: str) -> None:
        self.tokenizer = PreTrainedTokenizerFast.from_pretrained(
            model_dir, local_files_only=True
        )
        self.model = GPT2LMHeadModel.from_pretrained(
            model_dir, local_files_only=True
        )
        self.model.to(self.device)
        self.model.eval()

    # ── Generation ───────────────────────────────────────────────────────────

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 120,
        temperature: float = 0.7,
        top_p: float = 0.9,
    ) -> str:
        """
        Auto-regressive text generation using HuggingFace model.generate().
        Returns only the newly generated tokens (not the prompt).
        """
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=200,
        ).to(self.device)

        input_len = inputs["input_ids"].shape[1]

        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
                repetition_penalty=1.2,
            )

        new_ids = output_ids[0][input_len:]
        return self.tokenizer.decode(new_ids, skip_special_tokens=True).strip()

    # ── Structured response ───────────────────────────────────────────────────

    def generate_structured(self, message: str, context: dict) -> str:
        """
        Produce a LearnInsight-style structured response.

        Order of response generation:
          1. Try a deterministic intent-aware response builder first.
             This avoids the old issue where different prompts mapped to the
             same generic nearest-neighbour template.
          2. Fall back to embedding similarity over candidate pools.
        """
        role = context.get("role", "student")
        score = context.get("average_score", 0)

        deterministic = self._structured_rule_response(message, context)
        if deterministic:
            return deterministic

        msg_emb = self._embed(message)
        candidates = self._candidate_pool(role, score)

        direct_ans = self._best_match(msg_emb, candidates["direct"])
        next_action = self._best_match(msg_emb, candidates["action"])
        checklist = self._best_match(msg_emb, candidates["checklist"])

        return self._format_structured_response(direct_ans, next_action, checklist)

    def _format_structured_response(self, direct_answer: str, next_action: str, checklist: list[str] | None = None) -> str:
        lines = [
            "Direct answer",
            direct_answer.strip(),
            "",
            "Recommended next action",
            next_action.strip(),
        ]
        if checklist:
            lines += ["", "Checklist"]
            for item in checklist:
                cleaned = str(item).strip(" -\n\t")
                if cleaned:
                    lines.append(f"- {cleaned}")
        return "\n".join(lines)

    def _structured_rule_response(self, message: str, context: dict) -> str | None:
        text = (message or "").strip()
        lowered = text.lower()
        role = context.get("role", "student")
        score = context.get("average_score", 0)

        if not lowered:
            return None

        topic = self._extract_topic(text)
        if role not in {"student", "teacher", "schooladministrator", "systemadministrator"}:
            role = "student"

        if role == "student":
            if self._looks_like_three_day_plan(lowered):
                direct = self._student_three_day_plan(topic, score)
                action = "Choose the most urgent subject now and block fixed study times for the next three days."
                checklist = [
                    "List all topics that may appear on the exam or assignment",
                    "Assign one main goal to each day",
                    "End each day with a short self-test",
                ]
                return self._format_structured_response(direct, action, checklist)

            if self._looks_like_study_plan(lowered):
                direct = self._student_topic_plan(topic, score)
                action = f"Write down the exact topics inside {topic} that feel weakest, then start with the hardest one first."
                checklist = [
                    f"Break {topic} into 3 to 5 small topics",
                    "Review one concept, then solve one example immediately",
                    "Track mistakes so the next study block is targeted",
                ]
                return self._format_structured_response(direct, action, checklist)

            if self._looks_like_prioritization(lowered):
                direct = "Prioritize assignments by deadline, grade weight, and how risky they are if delayed. Do the item with the closest deadline or biggest grade impact first, not the easiest one."
                action = "Make a ranked list of every pending assignment right now using deadline, points, and estimated time, then begin the top item immediately."
                checklist = [
                    "List all pending assignments",
                    "Mark deadline, weight, and time needed",
                    "Start the top-ranked item before opening anything else",
                ]
                return self._format_structured_response(direct, action, checklist)

            if self._looks_like_explain_request(lowered):
                direct = self._student_explanation(topic)
                action = f"Tell the assistant the exact concept inside {topic} that confuses you most, then ask for one example and one practice question."
                checklist = [
                    "Name the exact concept or chapter",
                    "Ask for a step-by-step explanation in simple words",
                    "Test yourself with one example after reading the explanation",
                ]
                return self._format_structured_response(direct, action, checklist)

        return None

    def _extract_topic(self, message: str) -> str:
        compact = re.sub(r"\s+", " ", (message or "").strip())
        if not compact:
            return "this topic"

        patterns = [
            r"(?:study plan|plan) for (.+)$",
            r"explain (?:a |an )?(?:difficult )?concept(?: in| about| for)? (.+)$",
            r"help me prioritize (.+)$",
            r"build a 3-day study plan(?: for)? (.+)$",
        ]
        lowered = compact.lower()
        for pattern in patterns:
            match = re.search(pattern, lowered)
            if match:
                raw = compact[match.start(1):match.end(1)].strip(" .:;,-")
                return raw or "this topic"

        generic_prefixes = [
            "make a study plan for ",
            "build a 3-day study plan for ",
            "help me prioritize ",
            "explain a difficult concept in ",
            "explain a difficult concept about ",
        ]
        for prefix in generic_prefixes:
            if lowered.startswith(prefix):
                return compact[len(prefix):].strip(" .:;,-") or "this topic"

        return "this topic"

    def _looks_like_study_plan(self, lowered: str) -> bool:
        return "study plan" in lowered or ("make a plan" in lowered and "study" in lowered)

    def _looks_like_three_day_plan(self, lowered: str) -> bool:
        return "3-day study plan" in lowered or "three-day study plan" in lowered

    def _looks_like_prioritization(self, lowered: str) -> bool:
        return "prioritize" in lowered and "assignment" in lowered

    def _looks_like_explain_request(self, lowered: str) -> bool:
        return lowered.startswith("explain") or "explain a difficult concept" in lowered

    def _student_three_day_plan(self, topic: str, score: float) -> str:
        strength_line = self._score_line(score)
        return (
            f"{strength_line} For {topic}, use a three-day cycle: day 1 for core concepts and notes cleanup, day 2 for guided practice, and day 3 for a timed self-test with error review. "
            "Keep each study block focused on one subtopic so you can see exactly where you are improving."
        )

    def _student_topic_plan(self, topic: str, score: float) -> str:
        strength_line = self._score_line(score)
        return (
            f"{strength_line} For {topic}, start with the foundation first, then move to worked examples, then finish with independent practice. "
            "A good study plan is specific: decide what you will review, what you will solve, and how you will check whether you actually understood it."
        )

    def _student_explanation(self, topic: str) -> str:
        if topic == "this topic":
            return (
                "To explain a difficult concept well, first define it in one short sentence, then break it into smaller ideas, and finally connect it to one concrete example. "
                "If a concept still feels vague, it usually means one prerequisite idea is missing."
            )
        return (
            f"For {topic}, start by understanding the purpose of the concept, then learn the key parts, and then work through one small example step by step. "
            f"Once you can explain {topic} in simple words without notes, your understanding is becoming solid."
        )

    def _score_line(self, score: float) -> str:
        if score < 60:
            return "Your current performance suggests you should rebuild the basics before pushing harder topics."
        if score < 80:
            return "You already have a workable base, so the next gain will come from consistent practice and mistake review."
        return "You are doing well, so you should spend less time rereading and more time on challenging practice."

    # ── Embedding helper ──────────────────────────────────────────────────────

    def _embed(self, text: str) -> torch.Tensor:
        """
        Mean-pool the model's token embeddings for the given text.
        Uses the input embedding matrix (wte) — fast, no forward pass needed.
        """
        ids = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=64,
        )["input_ids"].to(self.device)

        with torch.no_grad():
            emb = self.model.transformer.wte(ids)   # (1, T, hidden)
        return emb.squeeze(0).mean(dim=0)           # (hidden,)

    def _cosine(self, a: torch.Tensor, b: torch.Tensor) -> float:
        return float(
            torch.nn.functional.cosine_similarity(
                a.unsqueeze(0), b.unsqueeze(0)
            ).item()
        )

    def _best_match(self, query_emb: torch.Tensor, pool: list) -> object:
        """
        Return the item from pool with highest embedding cosine similarity
        to query_emb.  pool can contain strings or lists of strings.
        """
        scored = []
        for item in pool:
            text = item if isinstance(item, str) else " ".join(item)
            item_emb = self._embed(text)
            scored.append((self._cosine(query_emb, item_emb), item))
        return max(scored, key=lambda x: x[0])[1]

    # ── Candidate pools ────────────────────────────────────────────────────────

    def _candidate_pool(self, role: str, score: float) -> dict:
        if role == "teacher":
            return {
                "direct": [
                    "Define a clear objective, write step-by-step instructions, and attach a rubric.",
                    "Identify which students need support using score and submission data, then act.",
                    "Break the topic into daily micro-tasks and set a clear deadline for each.",
                    "Design one activity that directly addresses the stated learning gap.",
                ],
                "action": [
                    "Identify the lowest-performing students and create one targeted intervention.",
                    "Send written feedback to the three students with the lowest recent scores.",
                    "Schedule a 10-minute check-in with at-risk students this week.",
                    "Grade one pending batch and note common errors for the next class.",
                ],
                "checklist": [
                    ["Set objective", "Write instructions", "Create rubric"],
                    ["Identify at-risk students", "Send feedback", "Check in 3 days"],
                    ["Plan activity", "Run it", "Assess outcome"],
                ],
            }
        if role in {"schooladministrator", "systemadministrator"}:
            return {
                "direct": [
                    "Review completion rate, login frequency, and assignment submission trends.",
                    "Analyse platform usage across roles and compare against baseline targets.",
                    "Audit the last 30 days of activity before making any system configuration change.",
                ],
                "action": [
                    "Compare engagement by role and fix the largest workflow bottleneck first.",
                    "Export a completion-rate report and share findings with department heads.",
                    "Audit recent login and submission data for anomalies before acting.",
                ],
                "checklist": [
                    ["Pull adoption metrics", "Check risk signals", "Prioritise one fix"],
                    ["Export activity log", "Find anomalies", "Document changes"],
                ],
            }
        # student (default)
        if score < 60:
            perf = "Your score suggests reviewing fundamentals before moving forward."
        elif score < 80:
            perf = "Good progress — more practice problems will close the remaining gaps."
        else:
            perf = "Strong performance — push to advanced topics and timed challenges."

        return {
            "direct": [
                f"{perf} Focus on one topic at a time and test yourself immediately.",
                "Break the assignment into three steps: understand, apply, review.",
                "Identify your weakest area first and spend the first study block there.",
                "Build a three-day plan: review on day one, practice on day two, mock test on day three.",
            ],
            "action": [
                "Start with the highest-deadline or lowest-score item and work for 25 minutes.",
                "Write three key points about this topic in your own words right now.",
                "Solve one example problem without notes, then check and correct your work.",
                "Complete all pending tasks before starting new material.",
            ],
            "checklist": [
                ["Pick one target", "Study or submit now", "Review mistakes after"],
                ["Read the concept", "Solve an example", "Note what was unclear"],
                ["List pending tasks", "Prioritise by deadline", "Complete the top one"],
            ],
        }

    # ── Model info ─────────────────────────────────────────────────────────────

    def describe(self) -> dict:
        cfg = self.model.config
        n_params = sum(p.numel() for p in self.model.parameters())
        return {
            "architecture":    "GPT-2 (Hugging Face transformers)",
            "library":         "transformers",
            "vocab_size":      cfg.vocab_size,
            "n_embd":          cfg.n_embd,
            "n_layer":         cfg.n_layer,
            "n_head":          cfg.n_head,
            "n_inner":         cfg.n_inner,
            "n_positions":     cfg.n_positions,
            "parameters":      n_params,
            "tokenizer":       "Byte-Level BPE (trained on LearnInsight corpus)",
            "device":          str(self.device),
            "backend":         "PyTorch CPU (Hugging Face transformers)",
        }
