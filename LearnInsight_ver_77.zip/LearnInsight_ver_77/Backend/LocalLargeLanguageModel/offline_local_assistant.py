from collections import Counter
import re


class OfflineLocalAssistant:
    def __init__(self):
        self.stopwords = {
            "the", "a", "an", "to", "for", "and", "or", "of", "in", "on", "with", "is", "are", "be", "this", "that",
            "what", "how", "why", "help", "me", "my", "please"
        }

    def _keywords(self, text):
        tokens = re.findall(r"[a-zA-Z']+", (text or "").lower())
        return [t for t in tokens if t not in self.stopwords and len(t) > 2]

    def generate(self, message, context=None):
        context = context or {}
        role = context.get("role", "student")
        keywords = self._keywords(message)
        common = ", ".join([k for k, _ in Counter(keywords).most_common(4)]) or "current priorities"

        if role == "teacher":
            return (
                "Direct answer\n"
                f"Focus this response on {common}. Break it into one immediate classroom action, one student support action, and one follow-up check.\n\n"
                "Recommended next action\n"
                "Choose the lowest-performing or least-engaged student group and create one short intervention for them this week.\n\n"
                "Checklist\n"
                "- Identify who needs support\n- Send clear feedback\n- Recheck progress in 3 days"
            )

        if role in {"schooladministrator", "systemadministrator"}:
            return (
                "Direct answer\n"
                f"Use {common} as a decision theme. Review adoption, completion, and risk signals before making system changes.\n\n"
                "Recommended next action\n"
                "Compare engagement by role and fix the largest workflow bottleneck first."
            )

        return (
            "Direct answer\n"
            f"Your message points to {common}. Turn it into one focused study block, one concrete deliverable, and one review step.\n\n"
            "Recommended next action\n"
            "Start with the highest-deadline or lowest-score item, work for 25 minutes, then check what improved.\n\n"
            "Checklist\n"
            "- Pick one target\n- Study or submit now\n- Review mistakes after"
        )
