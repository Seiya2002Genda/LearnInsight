
class TeacherAI:
    def generate_assignment(self, subject, topic):
        return f"""Assignment Builder

Subject: {subject}
Topic: {topic}

Objective
Students will explain the concept clearly, apply it once, and reflect on their reasoning.

Suggested instructions
1. Define the topic in your own words.
2. Provide one real example or worked problem.
3. Explain why the example fits the topic.
4. Write a short reflection on what was difficult.

Suggested rubric
- Accuracy: 40%
- Clarity: 25%
- Application: 25%
- Reflection: 10%"""
