
class RecommendLearningPlan:
    def __init__(self, learning_model):
        self.learning_model = learning_model

    def recommend(self, average_score, study_time):
        prediction = self.learning_model.predict_score(study_time)

        if average_score < 60 or prediction < 60:
            return {
                "level": "High Priority",
                "message": "Performance signals show that you are at risk of falling behind.",
                "action": "Block a focused review session today, finish one pending task, and revisit weak fundamentals.",
            }

        if average_score < 80 or prediction < 80:
            return {
                "level": "Medium Priority",
                "message": "Your progress is moving, but it is not stable enough yet.",
                "action": "Use short daily study blocks, review errors, and turn unfinished work into a fixed plan.",
            }

        return {
            "level": "Strong Progress",
            "message": "Your recent pattern is healthy and sustainable.",
            "action": "Maintain the routine, raise difficulty slightly, and keep submitting work on time.",
        }
