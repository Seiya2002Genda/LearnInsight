
from LearnInsight_ver_77.Backend.System.LearningSummaryService import LearningSummaryService


class MakeLearningReport:
    def __init__(self):
        self.summary_service = LearningSummaryService()

    def generate_report(self, user, records):
        summary = self.summary_service.build(records)
        return {
            "total_study_time": summary["total_study_time"],
            "average_score": summary["average_score"],
            "record_count": summary["total_records"],
        }

    def learning_summary(self, user, records):
        summary = self.summary_service.build(records)
        return summary
