
from statistics import mean


class LearningSummaryService:
    def build(self, records, assignments=None, submissions=None, tasks=None):
        records = records or []
        assignments = assignments or []
        submissions = submissions or []
        tasks = tasks or []

        scores = [float(r.get("score")) for r in records if r.get("score") is not None]
        study_times = [float(r.get("study_time")) for r in records if r.get("study_time") is not None]
        graded_submission_scores = [float(s.get("grade")) for s in submissions if s.get("grade") is not None]

        base_scores = graded_submission_scores or scores
        average_score = round(mean(base_scores), 2) if base_scores else 0.0
        total_study_time = round(sum(study_times), 2)
        total_records = len(records)
        assignment_count = len(assignments)
        submission_count = len(submissions)
        completed_tasks = len([t for t in tasks if t.get("status") == "completed"])
        pending_tasks = len([t for t in tasks if t.get("status") != "completed"])
        completion_rate = round((submission_count / assignment_count) * 100, 2) if assignment_count else 0.0

        recent_scores = base_scores[-3:] if len(base_scores) >= 3 else base_scores
        momentum = "Stable"
        if len(recent_scores) >= 2:
            if recent_scores[-1] > recent_scores[0]:
                momentum = "Upward"
            elif recent_scores[-1] < recent_scores[0]:
                momentum = "Downward"

        consistency = "Low"
        if total_study_time >= 10 or total_records >= 5:
            consistency = "Medium"
        if total_study_time >= 20 or total_records >= 10:
            consistency = "High"

        risk_level = "Low"
        if average_score < 60 or completion_rate < 60:
            risk_level = "High"
        elif average_score < 75 or completion_rate < 80:
            risk_level = "Medium"

        focus_area = "Maintain momentum"
        if pending_tasks >= 3:
            focus_area = "Reduce open tasks"
        elif average_score and average_score < 70:
            focus_area = "Improve weak subjects"
        elif completion_rate < 100:
            focus_area = "Submit pending assignments"

        return {
            "average_score": average_score,
            "total_study_time": total_study_time,
            "total_records": total_records,
            "assignment_count": assignment_count,
            "submission_count": submission_count,
            "completion_rate": completion_rate,
            "completed_tasks": completed_tasks,
            "pending_tasks": pending_tasks,
            "learning_trend": momentum,
            "consistency": consistency,
            "risk_level": risk_level,
            "focus_area": focus_area,
        }
