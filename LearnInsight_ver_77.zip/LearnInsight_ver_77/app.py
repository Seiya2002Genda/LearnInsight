import os
from LearnInsight_ver_77.Backend import create_app

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = create_app(
    template_folder=os.path.join(BASE_DIR, "FrontEnd", "templates"),
    static_folder=os.path.join(BASE_DIR, "FrontEnd", "static")
)

if __name__ == "__main__":
    app.run(debug=True)
