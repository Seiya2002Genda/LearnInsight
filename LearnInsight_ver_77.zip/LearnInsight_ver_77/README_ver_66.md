# LearnInsight ver 66

LearnInsight ver 66 is a rebuilt version of the education SaaS prototype with a cleaner UI hierarchy, a stronger student Learning Summary, and an OpenAI-free local assistant strategy.

## Major rebuild points
- Improved information hierarchy for dashboard, student, and teacher pages
- Database config moved to environment-variable-friendly configuration
- Missing tables and columns normalized in `CreateDatabase.py`
- Better Learning Summary with completion rate, consistency, risk level, and focus area
- Local LLM strategy that prefers Ollama and falls back to an offline local assistant
- Shared visual system through `FrontEnd/static/css/app.css`

## Environment variables
- `LEARNINSIGHT_DB_HOST`
- `LEARNINSIGHT_DB_PORT`
- `LEARNINSIGHT_DB_USER`
- `LEARNINSIGHT_DB_PASSWORD`
- `LEARNINSIGHT_DB_NAME`
- `LEARNINSIGHT_SECRET_KEY`
- `LEARNINSIGHT_LOCAL_MODEL`
- `LEARNINSIGHT_OLLAMA_URL`

## Local AI
### Tier 1
Use Ollama on your machine.

### Tier 2
If Ollama is offline, LearnInsight uses `OfflineLocalAssistant`, which is not a foundation model replacement but still provides local guided responses without OpenAI.

## Run
```bash
python app.py
```
